package finalproject;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.google.gson.Gson;

@WebServlet("/signup")
public class SignUpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    //FOR MY TEAMMATES: CHANGE THE DATABASE CREDENTIALS HERE
  	private static final String sqlusername= "root";
  	private static final String sqlpassword = "AWang@SQL01!";
    
    // Binary Search Tree for tracking signups
    private static class SignupNode {
        int userId;
        int sessionId;
        long timestamp;
        SignupNode left;
        SignupNode right;
        
        SignupNode(int userId, int sessionId) {
            this.userId = userId;
            this.sessionId = sessionId;
            this.timestamp = System.currentTimeMillis();
            this.left = null;
            this.right = null;
        }
    }

    private SignupNode root = null;

    // Insert into BST
    private void insertSignup(int userId, int sessionId) {
        root = insertRec(root, userId, sessionId);
    }

    private SignupNode insertRec(SignupNode root, int userId, int sessionId) {
        if (root == null) {
            return new SignupNode(userId, sessionId);
        }
        
        // use userId as the key for the BST
        if (userId < root.userId) {
            root.left = insertRec(root.left, userId, sessionId);
        } else if (userId > root.userId) {
            root.right = insertRec(root.right, userId, sessionId);
        } else {
            // user already exists, update session
            root.sessionId = sessionId;
            root.timestamp = System.currentTimeMillis();
        }
        
        return root;
    }

    // Search in BST
    private boolean isUserSignedUp(int userId) {
        return searchRec(root, userId) != null;
    }

    private SignupNode searchRec(SignupNode root, int userId) {
        if (root == null || root.userId == userId) {
            return root;
        }
        
        if (userId < root.userId) {
            return searchRec(root.left, userId);
        }
        
        return searchRec(root.right, userId);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String email = request.getParameter("email");

        if (email == null || email.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().println("Missing email parameter.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", sqlusername, sqlpassword)) {

            // get user ID
            PreparedStatement findUser = conn.prepareStatement("SELECT UserID FROM Users WHERE Email = ?");
            findUser.setString(1, email);
            ResultSet rsUser = findUser.executeQuery();

            if (!rsUser.next()) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().println("User not found.");
                return;
            }

            int userId = rsUser.getInt("UserID");

            // get session IDs from Favorites table
            PreparedStatement fetchFavorites = conn.prepareStatement(
                "SELECT SessionID FROM Favorites WHERE UserID = ?");
            fetchFavorites.setInt(1, userId);
            ResultSet rs = fetchFavorites.executeQuery();

            List<Integer> sessionIds = new ArrayList<>();
            while (rs.next()) {
                sessionIds.add(rs.getInt("SessionID"));
            }

            // send response of favorited session IDs
            response.setContentType("application/json");
            Gson gson = new Gson();
            response.getWriter().print(gson.toJson(sessionIds));

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
    
    	//Initial BST-only approach
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
//        // Check if user is signed up using BST
//        String userIdParam = request.getParameter("userId");
//        if (userIdParam != null) {
//            int userId = Integer.parseInt(userIdParam);
//            boolean isSignedUp = isUserSignedUp(userId);
//            
//            response.setContentType("application/json");
//            response.getWriter().print(new Gson().toJson(
//                java.util.Map.of("isSignedUp", isSignedUp)
//            ));
//        } else {
//            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
//        }
//    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Gson gson = new Gson();
        SignupRequest signupRequest = gson.fromJson(request.getReader(), SignupRequest.class);
        String email = signupRequest.getEmail();
        int sessionId = signupRequest.getSessionId();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", sqlusername, sqlpassword)) {

            // lookup user ID from email
            PreparedStatement findUser = conn.prepareStatement("SELECT UserID FROM Users WHERE Email = ?");
            findUser.setString(1, email);
            ResultSet rsUser = findUser.executeQuery();

            if (!rsUser.next()) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().println("User not found.");
                return;
            }

            int userId = rsUser.getInt("UserID");

            // insert into favorites
            PreparedStatement insert = conn.prepareStatement(
                "INSERT IGNORE INTO Favorites (UserID, SessionID) VALUES (?, ?)");
            insert.setInt(1, userId);
            insert.setInt(2, sessionId);
            insert.executeUpdate();

            // insert into in-memory BST
            insertSignup(userId, sessionId);

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().println("Signed up successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
    
    private static class SignupRequest {
        private String email;
        private int sessionId;

        public String getEmail() { return email; }
        public int getSessionId() { return sessionId; }
    }

    // Add this method to the class:
private SignupNode deleteRec(SignupNode root, int userId) {
    if (root == null) {
        return null;
    }
    
    if (userId < root.userId) {
        root.left = deleteRec(root.left, userId);
    } else if (userId > root.userId) {
        root.right = deleteRec(root.right, userId);
    } else {
        // Node with only one child or no child
        if (root.left == null) {
            return root.right;
        } else if (root.right == null) {
            return root.left;
        }
        
        // Node with two children: Get the inorder successor
        root.userId = findMinValue(root.right);
        
        // Delete the inorder successor
        root.right = deleteRec(root.right, root.userId);
    }
    
    return root;
}

    private int findMinValue(SignupNode root) {
        int minValue = root.userId;
        while (root.left != null) {
            minValue = root.left.userId;
            root = root.left;
        }
        return minValue;
    }

    private void removeSignup(int userId) {
        root = deleteRec(root, userId);
    }

    // And update doDelete to use it:
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String pathInfo = request.getPathInfo();
        if (pathInfo != null && pathInfo.length() > 1) {
            int userId = Integer.parseInt(pathInfo.substring(1));
            
            // Remove from BST
            removeSignup(userId);
            
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }


    
}
